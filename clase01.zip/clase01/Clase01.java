public class Clase01 {
    public static void main(String[] args) {
        
        //Linea de comentarios
        /*
         * Bloque
         * de 
         * comentarios
         */

        System.out.println("Hola Mundo!");  //Imprime en consola
        // ; es el terminador de sentencia
        // Leguaje es Case Sensitive (Sensible a Minusculas y Masyusculas)
        // F5 para ejecutar el programa

        // sout |TAB|       atajo de teclado para System.out.println();
        System.out.println("Hoy es Martes!");
        System.out.println("Centro de Formación Profesional Nro 35");
        System.out.print("1");
        System.out.print("2");
        System.out.print("3");
        System.out.println("4");
        System.out.println("Aprendiendo Java!");

        /*
            Hoy es Martes!
            Centro de Formación Profesional Nro 35
            1234
            Aprendiendo Java!

         */

        System.out.println("Versión de Java: "+
            System.getProperty("java.version"));

        //Colores
        String ANSI_BLACK = "\u001B[30m";
        String ANSI_RED = "\u001B[31m";
        String ANSI_GREEN = "\u001B[32m";
        String ANSI_YELLOW = "\u001B[33m";
        String ANSI_BLUE = "\u001B[34m";
        String ANSI_PURPLE = "\u001B[35m";
        String ANSI_CYAN = "\u001B[36m";
        String ANSI_WHITE = "\u001B[37m";
        String ANSI_RESET = "\u001B[0m";    

        System.out.println(ANSI_BLACK+"JAVA");
        System.out.println(ANSI_RED+"JAVA");
        System.out.println(ANSI_GREEN+"JAVA");
        System.out.println(ANSI_YELLOW+"JAVA");
        System.out.println(ANSI_BLUE+"JAVA");
        System.out.println(ANSI_PURPLE+"JAVA");
        System.out.println(ANSI_CYAN+"JAVA");
        System.out.println(ANSI_WHITE+"JAVA");
        System.out.println(ANSI_RESET+"JAVA");

        //Ingreso de datos por consola (teclado)
        System.out.print(ANSI_GREEN+"Ingrese su nombre: ");
        String nombre=new java.util.Scanner(System.in).nextLine();
        System.out.println(ANSI_RED+"Hola "+nombre);

        //Arte Ascii jdk 16 o sup
        System.out.println(ANSI_YELLOW+"""
                ░░░░░░░░░░░░░░░░░░░░░░█████████
                ░░███████░░░░░░░░░░███▒▒▒▒▒▒▒▒███
                ░░█▒▒▒▒▒▒█░░░░░░░███▒▒▒▒▒▒▒▒▒▒▒▒▒███
                ░░░█▒▒▒▒▒▒█░░░░██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒██
                ░░░░█▒▒▒▒▒█░░░██▒▒▒▒▒██▒▒▒▒▒▒██▒▒▒▒▒███
                ░░░░░█▒▒▒█░░░█▒▒▒▒▒▒████▒▒▒▒████▒▒▒▒▒▒██
                ░░░█████████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒██
                ░░░█▒▒▒▒▒▒▒▒▒▒▒▒█▒▒▒▒▒▒▒▒▒█▒▒▒▒▒▒▒▒▒▒▒██
                ░██▒▒▒▒▒▒▒▒▒▒▒▒▒█▒▒▒██▒▒▒▒▒▒▒▒▒▒██▒▒▒▒██
                ██▒▒▒███████████▒▒▒▒▒██▒▒▒▒▒▒▒▒██▒▒▒▒▒██
                █▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒█▒▒▒▒▒▒████████▒▒▒▒▒▒▒██
                ██▒▒▒▒▒▒▒▒▒▒▒▒▒▒█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒██
                ░█▒▒▒███████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒██
                ░██▒▒▒▒▒▒▒▒▒▒████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒█
                ░░████████████░░░█████████████████
                """);

        //Todo Variables




    }
}
